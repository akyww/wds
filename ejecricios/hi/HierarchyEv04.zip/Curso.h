/*
 * Curso.h
 *
 *  Created on: 22 jun. 2017
 *      Author: christian
 */

#ifndef CURSO_H_
#define CURSO_H_

#include <string>

class Curso {
public:
	Curso();
	 ~Curso();
private:
	 float nota;
	 std::string nombre;
};

#endif /* CURSO_H_ */
