/*
 * Curso.cpp
 *
 *  Created on: 22 jun. 2017
 *      Author: christian
 */

#include "Curso.h"

Curso::Curso() {
	// TODO Auto-generated constructor stub

}

Curso::~Curso() {
	// TODO Auto-generated destructor stub
}

